module.exports = () => {
    return ('' + Math.random()).substring(2, 7);
}